#include "freeCGI.h"

int main()
{
  //a_Empty template
  
  return 667;  //a_Return of the neighbor across the street from the beast
